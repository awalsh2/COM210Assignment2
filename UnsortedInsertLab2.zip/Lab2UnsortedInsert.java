/*
Author: Aidan Walsh/Stephanie Harders
 */
package lab2unsortedinsert;
import java.util.Arrays;
public class Lab2UnsortedInsert {

    public static void main(String[] args) {
          // creating small sorted array
        int[] SSArray = new int[10];
        for (int i = 0; i < SSArray.length; i++) {  
            SSArray[i] = i;
        }
        
        // unsorted insert on small array
        int[] SSArrayInserted = unsortedInsert(SSArray, 3, 25);
        System.out.println("small array with 25 inserted at index 3: " + Arrays.toString(SSArrayInserted));
        
        // creating medium sorted array
        int[] MSArray = new int[100];
        for (int n = 0; n < MSArray.length; n++) {  
            MSArray[n] = n;
        }
        
        // unsorted insert on medium array
        int[] MSArrayInserted = unsortedInsert(MSArray, 46, 120);
        System.out.println("Medium array with 120 inserted at index 46: " + Arrays.toString(MSArrayInserted));
        
        // creating large sorted array
        int[] LSArray = new int[1000];
        for (int j = 0; j < LSArray.length; j++) {  
            LSArray[j] = j;
        }
        
        // unsorted insert on large array
        int[] LSArrayInserted = unsortedInsert(LSArray, 200, 350);
        System.out.println("Large array with 350 inserted at index 200: " + Arrays.toString(LSArrayInserted));
    }
    
    public static int[] unsortedInsert(int[] array, int index, int value) {
        int[] newArray = new int[array.length+1];
        for (int i = 0; i < array.length; i++) {
            if (i < index) {
                newArray[i] = array[i];
            } else {
                newArray[i+1] = array[i];
            }
        }
        newArray[index] = value;
        return newArray;
    }

    }
    

