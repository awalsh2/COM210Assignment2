/*
Author: Aidan Walsh/Stephanie Harders
*/
package lab2;

public class UnsortedFetchLab2 {

    public static void main(String[] args) { 

     // creating small sorted array
        int count=0;
        int[] SSArray = new int[10];
        for (int i = 0; i < SSArray.length; i++) {  
            SSArray[i] = i;
            count=count+1;
        }
        System.out.println("The amount of steps the algorithm took was " + count);
        
        // unsorted fetch on small array
        int index = unsortedFetch(SSArray, 8);
        System.out.println("Index of 8 in small array: " + index);
        
        
        // creating medium  sorted array
        int count2=0;
        int[] MSArray = new int[100];
        for (int n = 0; n < MSArray.length; n++) {  
            MSArray[n] = n;
            count2=count2+1;
        }
        System.out.println("The amount of steps this algorithm took was " + count2);
        // unsorted fetch on medium array
        index = unsortedFetch(MSArray, 70);
        System.out.println("Index of 70 in medium array: " + index);
        
        // creating large sorted array
        int count3 = 0;
        int[] LSArray = new int[1000];
        for (int j = 0; j < LSArray.length; j++) {  
            LSArray[j] = j;
            count3=count3+1;
        }
        System.out.println("The amount of steps this algorithm took was " + count3);
        
        // unsorted fetch on large array
        index = unsortedFetch(LSArray, 600);
        System.out.println("Index of 600 in large array: " + index);
    
    }
    public static int unsortedFetch(int[] array, int value) {
        for (int i = 0; i < array.length; i++) {
            if (array[i] == value) {
                return i;
            }
        }
        return -1;
    }

}

    
    

